interface IPreviewContainerState {
    showCallout: boolean;
    isLoading: boolean;
    isVideoPaused: boolean;
}

export default IPreviewContainerState;