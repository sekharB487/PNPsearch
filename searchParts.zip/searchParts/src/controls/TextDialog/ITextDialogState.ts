export interface ITextDialogState {
  dialogText: string;
  showDialog: boolean;
}