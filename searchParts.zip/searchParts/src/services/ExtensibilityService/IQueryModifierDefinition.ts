export interface IQueryModifierDefinition<T> {
  displayName: string;
  description: string;
  class: T;
}
