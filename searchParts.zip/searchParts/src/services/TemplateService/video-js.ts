import 'video.js/dist/video-js.min.css';
import videojs from 'video.js';

export default class VideoJs {
    public static getVideoJs(){
        return videojs;
    }
}