export interface IUserInfo {
  AccountName: string;
  Properties: {
    [property: string]: any
  };
}