enum RefinersLayoutOption {
    Horizontal,
    Vertical,
    LinkAndPanel
}

export default RefinersLayoutOption;
