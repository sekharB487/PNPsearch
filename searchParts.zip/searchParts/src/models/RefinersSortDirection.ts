enum RefinerSortDirection {
    Ascending = 1,
    Descending = 2
}

export default RefinerSortDirection;