export enum SearchComponentType {
    SearchResultsWebPart = 'searchResultsWebPart',
    RefinersWebPart = 'refinersWebPart',
    PaginationWebPart = 'paginationWebPart',
    SearchBoxWebPart = 'searchQuery',
    SearchVerticalsWebPart = 'searchVerticals',
    PageEnvironment = 'PageContext'
}