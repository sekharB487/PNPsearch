interface ISynonymTable {
    [key: string]: string[];
}

export default ISynonymTable;