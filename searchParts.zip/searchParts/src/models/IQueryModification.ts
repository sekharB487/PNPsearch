export interface IQueryModifierInput {
  queryText: string;
  queryTemplate: string;
  resultSourceId: string;
}

export interface IQueryModification {
  queryText: string;
  queryTemplate: string;
}
