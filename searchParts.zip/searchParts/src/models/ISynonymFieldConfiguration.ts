export interface ISynonymFieldConfiguration {
    Term: string;
    Synonyms: string;
    TwoWays: boolean;
}

