enum RefinersSortOption {
    Alphabetical = 1,
    ByNumberOfResults = 2,
    Default = 3
}

export default RefinersSortOption;
