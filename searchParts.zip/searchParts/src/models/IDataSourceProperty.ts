interface IDataSourceProperty {
    key: string;
    text: string;
}

export default IDataSourceProperty;