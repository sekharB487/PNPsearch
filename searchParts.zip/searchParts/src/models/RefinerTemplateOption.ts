enum RefinerTemplateOption {
    DateRange = 1,
    CheckBox = 2,
    CheckBoxMulti = 3,
    Alphabetical = 4,
    FixedDateRange = 5,
    Persona = 6,
    FileType = 7,
    FileTypeMulti = 8,
    ContainerTree = 9
}

export default RefinerTemplateOption;
