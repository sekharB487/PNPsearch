interface ISearchResultsTemplateState {
    
    /**
     * The handlebar compiled template
     */
    processedTemplate: string;
}

export default ISearchResultsTemplateState;