interface ISearchVerticalsContainerState {

    /**
     * The current selected vertical key
     */
    selectedKey: string;
}

export default ISearchVerticalsContainerState;